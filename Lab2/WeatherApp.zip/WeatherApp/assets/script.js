var openWeatherMap = 'http://api.openweathermap.org/data/2.5/weather'
if (window.navigator && window.navigator.geolocation) {
    window.navigator.geolocation.getCurrentPosition(function(position) {
        $.getJSON(openWeatherMap, {
            lat: position.coords.latitude,
            lon: position.coords.longitude,
            units: 'imperial',
            APPID: '430e031680247a3fe3aaecd6ff3d69cf'
        }).done(function(weather_info) {
            console.log(weather_info)
            var icon = "https://openweathermap.org/img/w/" + weather_info.weather[0].icon + ".png";
            console.log(icon);
            $(".icon").attr("src", icon);
            var description = weather_info.weather[0].description;
            console.log(description);
            $(".weather").append(description)
            $(".temp").append(`${weather_info.main.temp}°`)
            $(".feelslike").append(`${weather_info.main.feels_like}°`)
            $(".tempmin").append(`${weather_info.main.temp_min}°`)
            $(".tempmax").append(`${weather_info.main.temp_max}°`)
            $(".cityCountry").append(weather_info.name + ", " + weather_info.sys.country)
            $(".estCoord").append(`${weather_info.coord.lat}°` + ", " + `${weather_info.coord.lon}°`)
            console.log(weather_info.name + ", " + weather_info.sys.country)
        })
    })
}
