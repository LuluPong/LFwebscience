console.log("testing1")

$(document).ready(function() {
    $.getJSON("news.json").done(function(news) {
        let i = 4;
        console.log(news);
        document.getElementById("news-image-1").setAttribute("src", `${news["news"][i-4]["image"]}`)
        document.getElementById("news-title-1").innerHTML = news["news"][i-4]["title"];
        document.getElementById("news-sub-1").innerHTML = news["news"][i-4]["author"];
        document.getElementById("news-1").innerHTML = news["news"][i-4]["description"];
        $("#news-link-1").append(`<a href='${news["news"][i-4]["url"]}' class='btn btn-primary'>See Article</a>`)

        document.getElementById("news-image-2").setAttribute("src", `${news["news"][i-3]["image"]}`)
        document.getElementById("news-title-2").innerHTML = news["news"][i-3]["title"];
        document.getElementById("news-sub-2").innerHTML = news["news"][i-3]["author"];
        document.getElementById("news-2").innerHTML = news["news"][i-3]["description"];
        $("#news-link-2").append(`<a href='${news["news"][i-3]["url"]}' class='btn btn-primary'>See Article</a>`)

        document.getElementById("news-image-3").setAttribute("src", `${news["news"][i-2]["image"]}`)
        document.getElementById("news-title-3").innerHTML = news["news"][i-2]["title"];
        document.getElementById("news-sub-3").innerHTML = news["news"][i-2]["author"];
        document.getElementById("news-3").innerHTML = news["news"][i-2]["description"];
        $("#news-link-3").append(`<a href='${news["news"][i-2]["url"]}' class='btn btn-primary'>See Article</a>`)

        document.getElementById("news-image-4").setAttribute("src", `${news["news"][i-1]["image"]}`)
        document.getElementById("news-title-4").innerHTML = news["news"][i-1]["title"];
        document.getElementById("news-sub-4").innerHTML = news["news"][i-1]["author"];
        document.getElementById("news-4").innerHTML = news["news"][i-1]["description"];
        $("#news-link-4").append(`<a href='${news["news"][i-1]["url"]}' class='btn btn-primary'>See Article</a>`)

        document.getElementById("news-image-5").setAttribute("src", `${news["news"][i]["image"]}`)
        document.getElementById("news-title-5").innerHTML = news["news"][i]["title"];
        document.getElementById("news-sub-5").innerHTML = news["news"][i]["author"];
        document.getElementById("news-5").innerHTML = news["news"][i]["description"];
        $("#news-link-5").append(`<a href='${news["news"][i]["url"]}' class='btn btn-primary'>See Article</a>`)
        
        
        setInterval(tickerTimer, 4700);

        function tickerTimer() {
            console.log(i);
            if (i < news.news.length) {
                document.getElementById("news-image-1").setAttribute("src", `${news["news"][i-4]["image"]}`)
                document.getElementById("news-title-1").innerHTML = news["news"][i-4]["title"];
                document.getElementById("news-sub-1").innerHTML = news["news"][i-4]["author"];
                document.getElementById("news-1").innerHTML = news["news"][i-4]["description"];
                $("#news-link-1").empty()
                $("#news-link-1").append(`<a href='${news["news"][i-4]["url"]}' class='btn btn-primary'>See Article</a>`)

                document.getElementById("news-image-2").setAttribute("src", `${news["news"][i-3]["image"]}`)
                document.getElementById("news-title-2").innerHTML = news["news"][i-3]["title"];
                document.getElementById("news-sub-2").innerHTML = news["news"][i-3]["author"];
                document.getElementById("news-2").innerHTML = news["news"][i-3]["description"];
                $("#news-link-2").empty()
                $("#news-link-2").append(`<a href='${news["news"][i-3]["url"]}' class='btn btn-primary'>See Article</a>`)

                document.getElementById("news-image-3").setAttribute("src", `${news["news"][i-2]["image"]}`)
                document.getElementById("news-title-3").innerHTML = news["news"][i-2]["title"];
                document.getElementById("news-sub-3").innerHTML = news["news"][i-2]["author"];
                document.getElementById("news-3").innerHTML = news["news"][i-2]["description"];
                $("#news-link-3").empty()
                $("#news-link-3").append(`<a href='${news["news"][i-2]["url"]}' class='btn btn-primary'>See Article</a>`)

                document.getElementById("news-image-4").setAttribute("src", `${news["news"][i-1]["image"]}`)
                document.getElementById("news-title-4").innerHTML = news["news"][i-1]["title"];
                document.getElementById("news-sub-4").innerHTML = news["news"][i-1]["author"];
                document.getElementById("news-4").innerHTML = news["news"][i-1]["description"];
                $("#news-link-4").empty()
                $("#news-link-4").append(`<a href='${news["news"][i-1]["url"]}' class='btn btn-primary'>See Article</a>`)

                document.getElementById("news-image-5").setAttribute("src", `${news["news"][i]["image"]}`)
                document.getElementById("news-title-5").innerHTML = news["news"][i]["title"];
                document.getElementById("news-sub-5").innerHTML = news["news"][i]["author"];
                document.getElementById("news-5").innerHTML = news["news"][i]["description"];
                $("#news-link-5").empty()
                $("#news-link-5").append(`<a href='${news["news"][i]["url"]}' class='align-self-end btn btn-primary'>See Article</a>`)

                i++;
                if (i == (news.news.length - 1)) {
                    i = 4;
                }
            }
        }
        ;
    })
});

function testing() {
    console.log("IT WORKS x2")
}